.onLoad <- function(...) {
  assign("bisse.ode",
         make.ode("derivs", "diversitree", "initmod", 4),
         asNamespace("diversitree"))
}

Rcomplex z_exp(Rcomplex z);
Rcomplex z_plus(Rcomplex a, Rcomplex b);
Rcomplex z_minus(Rcomplex a, Rcomplex b);
Rcomplex z_times(Rcomplex a, Rcomplex b);
Rcomplex z_divide(Rcomplex a, Rcomplex b);
Rcomplex z_scal(Rcomplex a, double x);

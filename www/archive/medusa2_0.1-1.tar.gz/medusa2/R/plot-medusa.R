plot2.phylo.medusa <- function(x, fit, cols, phy.full=x, ...) {
  if ( length(fit$split.at) != length(cols) )
    stop("Wrong number of colours")
  is.clade.tree <- inherits(x, "clade.tree")

  ## The split goes against the full tree:
  classes <- phy.split.nodes(fit$split.at[-1], phy.full)

  ## Identify all the nodes within the original tree:
  i <- match(x$node.label, phy.full$node.label)
  class.node <- classes[match(i + length(phy.full$tip.label),
                              phy.full$edge[,2])]

  if ( is.clade.tree ) {
    if ( !all(x$tip.label %in% names(x$clades)) )
      stop("Must deal with this...")
    class.tip <- lapply(x$clades[x$tip.label], function(y)
                        unique(classes[match(match(y, phy.full$tip.label),
                                             phy.full$edge[,2])]))
    class.tip.1 <- sapply(class.tip, function(y)
                          if (length(y) == 1) y else NA)
  } else {
    class.tip.1 <- class.tip <-
      classes[match(match(x$tip.label, phy.full$tip.label),
                    phy.full$edge[,2])]
  }

  ## Choose a unique class:
  class <- c(class.tip.1, class.node)[x$edge[,2]]

  if ( is.clade.tree )
    ret <- plot(x, edge.color=cols[class], ...)
  else
    ret <- plot2.phylo(x, edge.color=cols[class], ...)

  ## TODO: This is entirely set up for fan plots.
  if ( is.clade.tree ) {
    multi <- names(which(is.na(class.tip.1)))
    ltt <- lapply(multi, ltt.medusa, x, phy.full, classes)

    idx <- match(multi, x$tip.label)
    dy <- ret$n.taxa[idx] / 2 - .5
    tmp <- subset(ret$xy.seg, horiz)[match(idx, x$edge[,2]),]

    dt <- dy / ret$n.spp * 2 * pi
    t0 <- tmp$theta0 - dt
    t1 <- tmp$theta0 + dt

    for ( i in seq_along(ltt) )
      sectors.barplot(ltt[[i]]$t, ltt[[i]]$n,
                      tmp$r0[i], tmp$r1[i], t0[i], t1[i],
                      cols[attr(ltt[[i]], "classes")])
  }

  ret
}

## This is based on code from MEDUSA, and is used for colouring a tree
## - some documentationg and thinking about generality might be useful
## here.
phy.split.nodes <- function(nodes, phy, groups=NULL) {
  f <- function(node, phy, groups=NULL) {
    edge <- phy$edge
    if ( is.null(groups) )
      groups <- rep(1, nrow(edge))
    i <- which(edge[,1] == node | edge[,2] %in%
               diversitree:::descendants(node, edge))
    base <- groups[match(node, edge[,2])]
    groups[i[groups[i] == base]] <- max(groups) + 1
    groups
  }

  if ( nodes[1] == length(phy$tip.label) + 1 )
    nodes <- nodes[-1]

  for ( i in nodes )
    groups <- f(i, phy, groups)
  groups
}

## Now, go back and fix up the cases with multiple rates.
## This is only correct to an approximation, unfortunately, but will
## suffice until I get the more complicated matters sorted out.
## I wonder about the reliance on panth here, and whether I can use
## class?
ltt.medusa <- function(x, phy.cl, phy.full, classes) {
  to.drop <- setdiff(phy.full$tip.label, sort(phy.cl$clades[[x]]))
  phy.sub <- diversitree:::drop.tip.fixed(phy.full, to.drop)
  bt <- sort(branching.times(phy.sub), decreasing=TRUE)
  ##cl <- classes[match(match(phy.sub$node.label, phy$node.label) +
  ##                    length(phy$tip.label), phy$edge[,2])]
  cl <- classes[match(match(phy.sub$node.label, phy.full$node.label) +
                      length(phy.full$tip.label), phy.full$edge[,2])]
  names(cl) <- phy.sub$node.label
  classes.sub <- sort(unique(cl))
  n <- rbind(0,
             sapply(classes.sub, function(x) 
                    cumsum(cl[names(bt)] == x)))
  i <- match(cl[names(bt[1])], classes.sub)
  n[,i] <- n[,i] + 1
  ret <- list(t=bt, n=n) #  / rowSums(n)
  attr(ret, "classes") <- classes.sub
  ret
}

## This could go in the general utilities file, but is quite likely to
## be specific for this case.
sectors.barplot <- function(x, y, r0, r1, t0, t1, cols, np=1000) {
  tm <- (t0 + t1)/2

  ## Positions of the three vertices of the sector, in (x,y) space:
  xm <- r0 * cos(tm) # inner, mid
  x0 <- r1 * cos(t0) # outer, bottom
  x1 <- r1 * cos(t1) # outer, top
  ym <- r0 * sin(tm) # inner, mid
  y0 <- r1 * sin(t0) # outer, bottom
  y1 <- r1 * sin(t1) # outer, top
  
  ## Normalise cumulative sum onto [0,1]
  yy <- t(apply(cbind(0, y), 1, cumsum)) / rowSums(y)
  
  ## Radii and outer angles for the sector:
  r2 <- c(r0, rep(r1 - x, each=2), r1)
  p <- (r2 - r0) / (r1 - r0)
  t2.0 <- atan2((1-p) * ym + p * y0, (1-p) * xm + p * x0) %% (2*pi)
  t2.1 <- atan2((1-p) * ym + p * y1, (1-p) * xm + p * x1) %% (2*pi)
  t2 <- t2.0 + yy[rep(seq_len(nrow(yy)), each=2),] * (t2.1 - t2.0)

  rt <- matrix(nrow=0, ncol=2)
  nn <- pmax(2, ceiling(diff(t2[nrow(t2),]) / (2 * pi) * np))

  for ( j in seq_len(ncol(y)) ) {
    rt.out <- cbind(r2, t2[,j])
    rt.mid <- cbind(rep(r1, nn[j]),
                    seq(t2[nrow(t2),j], t2[nrow(t2),j+1], length=nn[j]))
    rt.in <- cbind(rev(r2), rev(t2[,j+1]))
    rt <- rbind(rt, rt.out, rt.mid, rt.in, NA)
  }
  
  polygon(rt[,1] * cos(rt[,2]),
          rt[,1] * sin(rt[,2]), border=NA, col=cols)
}

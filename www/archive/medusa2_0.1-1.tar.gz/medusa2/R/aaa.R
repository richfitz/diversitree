descendants <- diversitree:::descendants

## runMedusa2:
##
## This function is similar to the original runMedusa.  It takes a
## phylogeny 'phy' and information about species richeness
## ('richness') and returns a list of models with 0, 1, 2, ...,
## model.limit partitions.  Rather than return a summary table (like
## runMedusa), the ith element in the return of runMedusa2 contains a
## list with information about the fit of a model with i-1 partitions
## (=i rate classes).  This list has elements:
##   par: i x 2 matrix; the jth row contains the speciation and
##     extinction rate for the jth rate class
##   lnLik.part: vector of length i; the jth element is the partial
##     log likelihood value due to the jth rate class
##   lnLik: = sum(lnLik.part); the overall log-likelihood of this
##      model
##   split.at: the i+1 locations of splits.  The first element is the
##     root node (representing the background rate).
##
## The species richness information is assumed to have columns
## "tip.label" and "n.taxa"; "tip.label" must match with a tip.label
## in the phylogeny "phy" (though this is not really checked below).
## If richness is ommited (or NULL), then tips are assumed to
## represent a single species.
runMedusa2 <- function(phy, richness=NULL, model.limit=20) {
  max.model.limit <- 2*length(phy$tip.label) - 2
  if ( model.limit > max.model.limit ) {
    warning("Reducing model.limit to ", max.model.limit)
    model.limit <- max.model.limit
  }
  
  obj <- make.cache.medusa(phy, richness)
  nodes <- seq_len(max(phy$edge))
  desc <- obj$desc
 
  z <- obj$z
  fit <- medusa.ml.initial(z)

  models <- vector("list", model.limit + 1)
  models[[1]] <- fit

  for ( i in seq_len(model.limit) ) {
    node.list <- nodes[-fit$split.at]
    res <- lapply(node.list, medusa.ml.update, z, desc, fit)
    best <- which.max(unlist(lapply(res, "[[", "lnLik")))
    z <- medusa.split(node.list[best], z, desc)$z

    fit <- models[[i+1]] <- res[[best]]
  }

  models
}


## The make.cache.medusa function is like the first half of
## splitEdgeMatrix(); it works through and reorders the branches, then
## works out start and end times of these based on the phylogeny's
## branching times.
##
## Rather than return a matrix, I am returning a list so that a few
## additional bits can easily be returned.  The edge matrix is
## reordered for consistency with the original MEDUSA, but the
## ordering is not really needed.
##
## The additional bit (c.f. MEDUSA) is that every node's descendants are
## also calculated.  The element 'desc' is a list; $desc[i] contains the
## indices within $edge, $t.start, etc., of all descendants of node 'i'
## (in ape node numbering format).
##
## This does not take into account clades that decrease in size, or
## that do not finish at the present (time=0).
make.cache.medusa <- function(phy, richness=NULL) {
  if ( is.null(richness) )
    richness <- data.frame(tip.label=phy$tip.label, n.taxa=1)
  else {
    ## TODO: check all species present, order appropriately, etc.
    richness <- richness[match(phy$tip.label, richness$tip.label),]
  }
  
  n.tip <- length(phy$tip.label)
  n.edge <- nrow(phy$edge)
  n.int <- n.edge - n.tip
  i.int <- seq_len(n.int)
  interior <- phy$edge[,2] %in% phy$edge[,1]
  bt <- branching.times(phy)

  edge <- rbind(phy$edge[interior,],
                phy$edge[match(seq_len(n.tip), phy$edge[,2]),])
  colnames(edge) <- c("anc", "dec")

  ## t0: start time, t1: end time, with an end time (t1) of 0 being a
  ## terminal branch that finishes at the present.
  t.0 <- bt[match(edge[,1], (n.tip+1):max(edge))]  
  t.1 <- c(t.0[i.int] - phy$edge.length[interior], rep(0, n.tip))

  z <- cbind(edge, t.0, t.1, t.len=t.0 - t.1,
             n0=rep(1, n.edge),
             nt=c(rep(NA, n.int), richness$n.taxa),
             group=rep(1, n.edge))
  rownames(z) <- NULL

  ## TODO: the descendents code here could be massively sped up
  list(z=z,
       desc=lapply(seq_len(max(edge)), descendants.idx, edge))
}

medusa.ml.fit.part <- function(group, z, sp=c(.1, .05)) {
  lik <- make.lik.medusa.part(z[z[,"group"] == group,,drop=FALSE])
  fit <- optim(lik, par=sp, method="N",
               control=list(fnscale=-1))
  list(par=fit$par, lnLik=fit$value)
}

## make.lik.medusa.part: generate a likelihood function for a single
## partition.
##
## In the terminal calculations, the variables 'A' and 'B' are the A
## and B terms in Foote et al. Science: 283 1310-1314, p. 1313,
## defined as
##   A: probability of extinction of one lineage over time 't'
##   B: lambda * A / mu
##
## Where there is a single lineage at time 0 (a=1), the calculation is
##   log(1 - A) + log(1 - B) + (n-1)*log(B)
## but this is conditioned on survival by dividing by (1-A)
## (subtracting log(1-A) on a log scale) which cancels to give
##   log(1 - B) + (n-1)*log(B)
##
## Where a > 1, the calculations are more complicated, and I have
## pulled them into the function 'foote.terminal' so the likelihood
## function is easier to understand.  Where a == 1 (i.e., a single
## starting species), the calculations are identical to those above.
## When a > 1 (more than one starting species), the calculations
## follow Foote et al. equation (9).
make.lik.medusa.part <- function(z) {
  is.int <- is.na(z[,"nt"])
  n.int <- sum(is.int)
  n.term <- nrow(z) - n.int

  int  <- z[ is.int,,drop=FALSE]
  term <- z[!is.int,,drop=FALSE]

  int.t.len <- sum(int[,"t.len"])
  int.t.0 <- int[,"t.0"]

  term.n0 <- term[,"n0"] # Foote's 'a': initial diversity
  term.nt <- term[,"nt"] # Foote's 'n': final diversity
  term.t.len <- term[,"t.len"]

  function(pars) {
    b <- pars[1]
    d <- pars[2]
    r <- abs(b - d)
    eps <- d / b
    
    if ( r < 0 | eps < 0 | eps >= 1 ) # TODO: too restrictive.
      ## Better:
      ## if ( is.nan(eps) || eps < 0 || xor(eps > 1, r < 0) )
      ## But requires use of abs(1-a) and abs(r) in a few places.
      return(-Inf)

    if ( n.int == 0 )
      l.int <- 0
    else 
      l.int <- n.int * log(r) - r * int.t.len -
        sum(log(1 - (eps * exp(-r * int.t.0))))

    if ( n.term == 0 ) {
      l.term <- 0
    } else {
      ##A <- (d * (exp((b-d)*term.t.len) - 1)) /
      ##  (b*exp((b-d)*term.t.len) - d)
      ##B <- b * A / d
      if ( all(term.n0==1) ) {
        bert <- b * exp(r * term.t.len)
        B <- (bert - b) / (bert - d)
        l.term <- sum(log(1 - B) + (term.nt-1)*log(B))
      } else {
        ert <- exp(r * term.t.len)
        A <- (d*(ert - 1)) / (b*ert - d)
        B <- b * A / d
        l.term <- foote.terminal(term.n0, term.nt, A, B)
      }
    }

    l.int + l.term
  }
}

foote.terminal <- function(a, n, A, B) {
  ## These will come in useful:
  lA <- log(A)
  lB <- log(B)
  l1mA <- log(1 - A)
  l1mB <- log(1 - B)
  l1mA1mB <- l1mA + l1mB

  ## Using the logic above for the cases where a == 1:
  idx <- a > 1
  nidx <- !idx
  l.term.a1 <- sum(l1mB[nidx] + (n[nidx]-1) * lB[nidx])

  min.a.n <- pmin(a[idx], n[idx])
  l.term.an <- numeric(length(min.a.n))
  ## Foote et al. 1999, equation (9):
  for ( i in which(idx) ) {
    j <- seq_len(min.a.n[i])
    ai <- a[i]
    ni <- n[i]

    tmp <- lchoose(ai, j) + lchoose(ni - 1, j - 1) +
      (ai-j)*lA[i] + j*l1mA1mB[i] + (ni-j)*lB[i]
    ## Conditioning on survival is done outside of the sum, as it
    ## factors out of all the sub expressions:
    l.term.an[i] <- logspace_sum(tmp) - l1mA[i]
  }

  l.term.a1 + sum(l.term.an)
}

## This generates the indices of all descendants of a node, using ape's
## edge matrix.
descendants <- function(node, edge) {
  ans <- node
  repeat {
    node <- edge[edge[,1] %in% node,2]
    if ( length(node) > 0 )
      ans <- c(ans, node)
    else
      break
  }

  unlist(ans)
}

## The function 'descendants' returns the indices of all descendants
## within the edge matrix.
descendants.idx <- function(node, edge)
  which(edge[,1] == node | edge[,2] %in% descendants(node, edge))

## Split the edge matrix 'z' by adding a partition rooted at node
## 'nd'.  The list 'desc' is a list of descendants (see
## make.cache.medusa, above).  It returns a list with elements:
##   z: new medusa matrix, with the new group added
##   affected: indices of the groups affected by the split.  This will
##     be new group and one other.
medusa.split <- function(node, z, desc) {
  grp <- z[,"group"]
  base <- min(grp[z[,1] == node | z[,2] == node])
  tag <- max(grp) + 1

  i <- desc[[node]]
  idx <- i[grp[i] == base]
  z[idx,"group"] <- tag

  list(z=z, affected=c(unique(grp[idx]), tag))
}

medusa.ml.update <- function(node, z, desc, fit) {
  obj <- medusa.split(node, z, desc)
  z <- obj$z
  aff <- obj$affected
  if ( length(aff) > 2 ) stop("This should not happen: FIXME?")

  op <- fit$par
  sp <- op[aff[1],]
  fit1 <- medusa.ml.fit.part(aff[1], z, sp)
  fit2 <- medusa.ml.fit.part(aff[2], z, sp)

  op[aff[1],] <- fit1$par
  fit$par <- rbind(op, fit2$par)
  fit$lnLik.part[aff] <- c(fit1$lnLik, fit2$lnLik)
  fit$split.at <- c(fit$split.at, node)
  fit$lnLik <- sum(fit$lnLik.part)

  fit
}

medusa.ml.initial <- function(z) {
  rootnode <- min(z[is.na(z[,"nt"]),1])
  obj <- medusa.ml.fit.part(1, z)
  list(par=matrix(obj$par, 1),
       lnLik.part=obj$lnLik,
       lnLik=obj$lnLik,
       split.at=rootnode)
}

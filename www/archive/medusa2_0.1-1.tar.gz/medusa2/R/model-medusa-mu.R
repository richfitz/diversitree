## Medusa with constrained Mu...
runMedusa2.mu <- function(phy, richness=NULL, model.limit=20, mu=0,
                          is.mu=TRUE) {
  max.model.limit <- 2*length(phy$tip.label) - 2
  if ( model.limit > max.model.limit ) {
    warning("Reducing model.limit to ", max.model.limit)
    model.limit <- max.model.limit
  }
  
  obj <- make.cache.medusa(phy, richness)
  nodes <- seq_len(max(phy$edge))
  desc <- obj$desc
 
  z <- obj$z
  fit <- medusa.ml.initial.mu(z, mu, is.mu)

  models <- vector("list", model.limit + 1)
  models[[1]] <- fit

  for ( i in seq_len(model.limit) ) {
    node.list <- nodes[-fit$split.at]
    res <- lapply(node.list, medusa.ml.update.mu, z, desc, fit, mu, is.mu)
    best <- which.max(unlist(lapply(res, "[[", "lnLik")))
    z <- medusa.split(node.list[best], z, desc)$z

    fit <- models[[i+1]] <- res[[best]]    
  }

  models
}

medusa.ml.initial.mu <- function(z, mu, is.mu) {
  rootnode <- min(z[is.na(z[,"nt"]),1])
  sp <- .1 # hack.
  obj <- medusa.ml.fit.part.mu(1, z, sp, mu, is.mu)
  list(par=obj$par,
       lnLik.part=obj$lnLik,
       lnLik=obj$lnLik,
       split.at=rootnode)
}

medusa.ml.update.mu <- function(node, z, desc, fit, mu, is.mu) {
  obj <- medusa.split(node, z, desc)
  z <- obj$z
  aff <- obj$affected
  if ( length(aff) > 2 ) stop("This should not happen: FIXME?")

  sp <- fit$par[aff[1]]
  fit1 <- medusa.ml.fit.part.mu(aff[1], z, sp, mu, is.mu)
  fit2 <- medusa.ml.fit.part.mu(aff[2], z, sp, mu, is.mu)

  fit$par[aff] <- c(fit1$par, fit2$par)
  fit$lnLik.part[aff] <- c(fit1$lnLik, fit2$lnLik)
  fit$split.at <- c(fit$split.at, node)
  fit$lnLik <- sum(fit$lnLik.part)

  fit
}

medusa.ml.fit.part.mu <- function(group, z, sp=.1, mu, is.mu) {
  lik <- make.lik.medusa.part.mu(z[z[,"group"] == group,,drop=FALSE],
                                 mu, is.mu)
  ## TODO: Use optimize() for one dimensional optimisation, but this
  ## requires bracketing.  With the current parameter constraints
  ## (lambda > mu) this requires
  lik2 <- protect(lik, lik(sp) - 100)
  fit <- suppressWarnings(optim(lik2, par=sp, method="N",
                                control=list(fnscale=-1)))
  list(par=fit$par, lnLik=fit$value)
}

make.lik.medusa.part.mu <- function(z, mu, is.mu) {
  lik <- make.lik.medusa.part(z)
  if ( is.mu )
    function(lambda) lik(c(lambda[1], mu))
  else
    function(lambda) lik(c(lambda[1], mu * lambda[1]))
}
